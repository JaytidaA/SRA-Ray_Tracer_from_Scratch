#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include "GL_Tracer_API/ekShaderUtils.hpp"
#include <cmath> 

float originalCenter[3] = {0.0, 0.0, -2.0};  
bool moveMode = false;
bool rotateMode = false;
float rotationAngle = 0.0f;

void processInput(GLFWwindow *window) {
    // Toggle move mode
    if (glfwGetKey(window, GLFW_KEY_M) == GLFW_PRESS)
        moveMode = true;
    else if (glfwGetKey(window, GLFW_KEY_M) == GLFW_RELEASE)
        moveMode = false;

    // Toggle rotate mode
    if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS)
        rotateMode = true;
    else if (glfwGetKey(window, GLFW_KEY_R) == GLFW_RELEASE)
        rotateMode = false;

    if (moveMode) {
        // Move the sphere left
        if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
            originalCenter[0] -= 0.01;

        // Move the sphere right
        if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
            originalCenter[0] += 0.01;

        // Move the sphere up
        if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
            originalCenter[1] += 0.01;

        // Move the sphere down
        if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
            originalCenter[1] -= 0.01;
    }

    if (rotateMode) {
        if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
            rotationAngle -= 0.01;

        if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
            rotationAngle += 0.01;
    }
}

int main(int argc, char **argv) {
    if (argc != 2) { return -1; }

    // Request specific OpenGL version (3.3 Core)
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow *my_Window;

    // Initialize the library
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW!" << std::endl;
        return -1;
    }

    // Create a windowed mode window and its OpenGL context
    my_Window = glfwCreateWindow(640, 640, "Raytracing with OpenGL", NULL, NULL);
    if (!my_Window) {
        std::cerr << "Failed to create GLFW window!" << std::endl;
        glfwTerminate();
        return -1;
    }

    
    glfwMakeContextCurrent(my_Window);
    glfwSwapInterval(1);

    
    std::cout << "OpenGL Version before GLEW: " << glGetString(GL_VERSION) << std::endl;

    glewExperimental = GL_TRUE;

    if (glewInit() != GLEW_OK) {
        std::cerr << "Failed to initialize GLEW!" << std::endl;
        return -1;
    }
    std::cout << "Window and OpenGL context successfully created!" << std::endl;

    int width, height;
    glfwGetFramebufferSize(my_Window, &width, &height);
    ekGLCall(glViewport(0, 0, width, height));

    ekGLCall(glEnable(GL_DEPTH_TEST));
    ekGLCall(glClearColor(0.0f, 0.0f, 0.0f, 1.0f));  // Set the background to black

    float vertices[] = {
        
        -1.0f,  1.0f,  0.0f,  1.0f,
        -1.0f, -1.0f,  0.0f,  0.0f,
         1.0f, -1.0f,  1.0f,  0.0f,
         1.0f,  1.0f,  1.0f,  1.0f
    };

    unsigned int indices[] = {
        0, 1, 2,
        2, 3, 0
    };

    unsigned int my_BufferIndex;
    ekGLCall(glGenBuffers(1, &my_BufferIndex));
    ekGLCall(glBindBuffer(GL_ARRAY_BUFFER, my_BufferIndex));
    ekGLCall(glBufferData(GL_ARRAY_BUFFER, 16 * sizeof(float), vertices, GL_STATIC_DRAW));

    unsigned int my_VertexArrayObjectIndex;
    ekGLCall(glGenVertexArrays(1, &my_VertexArrayObjectIndex));
    ekGLCall(glBindVertexArray(my_VertexArrayObjectIndex));

    unsigned int my_IndexBufferObjectIndex;
    ekGLCall(glGenBuffers(1, &my_IndexBufferObjectIndex));
    ekGLCall(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, my_IndexBufferObjectIndex));
    ekGLCall(glBufferData(GL_ELEMENT_ARRAY_BUFFER, 6 * sizeof(unsigned int), indices, GL_STATIC_DRAW));

    ekGLCall(glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 4, (const void *)0));
    ekGLCall(glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 4, ((const void *)(sizeof(float) * 2))));
    ekGLCall(glEnableVertexAttribArray(0));
    ekGLCall(glEnableVertexAttribArray(1));

    // Compile and link shaders
    shaderProgramSource ps = parse_file(argv[1]);
    unsigned int my_Program = create_shader(ps.shaderVertexSource, ps.shaderFragmentSource);

    
    int success;
    char infoLog[512];

    
    // Program linking error check
    glGetProgramiv(my_Program, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(my_Program, 512, NULL, infoLog);
        std::cerr << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
    }

    ekGLCall(glUseProgram(my_Program));

    unsigned int sCenter = glGetUniformLocation(my_Program, "sCenter");
    if (sCenter == -1) {
        std::cerr << "WARNING: 'sCenter' uniform not found or not used in shader." << std::endl;
    }

    // Unbinding buffers
    ekGLCall(glBindVertexArray(0));
    ekGLCall(glBindBuffer(GL_ARRAY_BUFFER, 0));
    ekGLCall(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0));
    ekGLCall(glUseProgram(0));

    while (!glfwWindowShouldClose(my_Window)) {
        processInput(my_Window);

        ekGLCall(glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT));

        
        glfwGetFramebufferSize(my_Window, &width, &height);
        ekGLCall(glViewport(width / 2 - 320, height / 2 - 320, 640, 640));

    
        ekGLCall(glUseProgram(my_Program));
        ekGLCall(glBindVertexArray(my_VertexArrayObjectIndex));
        ekGLCall(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, my_IndexBufferObjectIndex));

        if (rotateMode) {
            // Create rotation matrix
            float rotationMatrix[9] = {
            (float)cos(rotationAngle), 0.0f, (float)-sin(rotationAngle),
            0.0f, 1.0f, 0.0f,
            (float)sin(rotationAngle), 0.0f, (float)cos(rotationAngle)
            };


            float rotatedCenter[3];
            for (int i = 0; i < 3; ++i) {
                rotatedCenter[i] = 
                    rotationMatrix[i * 3 + 0] * originalCenter[0] + 
                    rotationMatrix[i * 3 + 1] * originalCenter[1] + 
                    rotationMatrix[i * 3 + 2] * originalCenter[2];
            }

            // Update the uniform with the rotated sphere position
            glUniform3fv(sCenter, 1, rotatedCenter);
        } else {
            // Update the uniform with the current sphere position
            glUniform3fv(sCenter, 1, originalCenter);
        }

        ekGLCall(glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr));

        ekGLCall(glBindVertexArray(0));
        ekGLCall(glBindBuffer(GL_ARRAY_BUFFER, 0));
        ekGLCall(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0));
        ekGLCall(glUseProgram(0));

        // Swap buffers
        glfwSwapBuffers(my_Window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}
